from fastapi import FastAPI, APIRouter, Depends, HTTPException, status, File, UploadFile
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
import os
import logging
from pathlib import Path
from pydantic import BaseModel, Field, ConfigDict, EmailStr
from typing import List, Optional
import uuid
from datetime import datetime, timezone, timedelta
from passlib.context import CryptContext
import jwt
import shutil
from slugify import slugify

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

# MongoDB connection
mongo_url = os.environ['MONGO_URL']
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ['DB_NAME']]

# Password hashing
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

# JWT settings
SECRET_KEY = os.environ.get('SECRET_KEY', 'revista-enfoco-secret-key-change-in-production')
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 60 * 24 * 7  # 7 days

# Security
security = HTTPBearer()

# Create the main app
app = FastAPI(title="Revista Enfoco API")

# Create a router with the /api prefix
api_router = APIRouter(prefix="/api")

# ============ MODELS ============

# User Models
class UserBase(BaseModel):
    email: EmailStr
    name: str
    role: str = "editor"  # admin or editor

class UserCreate(UserBase):
    password: str

class UserLogin(BaseModel):
    email: EmailStr
    password: str

class User(UserBase):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class UserInDB(User):
    hashed_password: str

class Token(BaseModel):
    access_token: str
    token_type: str
    user: User

# Post Models (Notícias)
class PostBase(BaseModel):
    title: str
    content: str
    excerpt: str
    category: str = "Geral"
    featured_image: Optional[str] = None
    published: bool = True

class PostCreate(PostBase):
    pass

class Post(PostBase):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    slug: str
    author_id: str
    author_name: str
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

# Column Models (Colunas)
class ColumnBase(BaseModel):
    title: str
    content: str
    excerpt: str
    featured_image: Optional[str] = None
    published: bool = True

class ColumnCreate(ColumnBase):
    pass

class Column(ColumnBase):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    slug: str
    author_id: str
    author_name: str
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

# Event Models (Eventos)
class EventBase(BaseModel):
    title: str
    description: str
    event_date: datetime
    location: Optional[str] = None
    published: bool = True

class EventCreate(EventBase):
    pass

class Event(EventBase):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    slug: str
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

# Edition Models (Edições)
class EditionBase(BaseModel):
    title: str
    description: str
    cover_image: Optional[str] = None
    edition_number: int
    pdf_url: Optional[str] = None
    published: bool = True

class EditionCreate(EditionBase):
    pass

class Edition(EditionBase):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    slug: str
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

# Media Models
class Media(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    filename: str
    url: str
    uploaded_by: str
    uploaded_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

# ============ HELPER FUNCTIONS ============

def verify_password(plain_password, hashed_password):
    return pwd_context.verify(plain_password, hashed_password)

def get_password_hash(password):
    return pwd_context.hash(password)

def create_access_token(data: dict):
    to_encode = data.copy()
    expire = datetime.now(timezone.utc) + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt

async def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(security)):
    token = credentials.credentials
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        user_id: str = payload.get("sub")
        if user_id is None:
            raise HTTPException(status_code=401, detail="Invalid authentication credentials")
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token has expired")
    except jwt.JWTError:
        raise HTTPException(status_code=401, detail="Could not validate credentials")
    
    user = await db.users.find_one({"id": user_id}, {"_id": 0})
    if user is None:
        raise HTTPException(status_code=401, detail="User not found")
    
    if isinstance(user.get('created_at'), str):
        user['created_at'] = datetime.fromisoformat(user['created_at'])
    
    return User(**{k: v for k, v in user.items() if k != 'hashed_password'})

def create_slug(title: str) -> str:
    return slugify(title)

# ============ AUTH ROUTES ============

@api_router.post("/auth/register", response_model=User)
async def register(user_data: UserCreate):
    # Check if user exists
    existing_user = await db.users.find_one({"email": user_data.email})
    if existing_user:
        raise HTTPException(status_code=400, detail="Email already registered")
    
    # Create user
    hashed_password = get_password_hash(user_data.password)
    user_dict = user_data.model_dump(exclude={'password'})
    user_obj = User(**user_dict)
    
    user_in_db = UserInDB(**user_obj.model_dump(), hashed_password=hashed_password)
    doc = user_in_db.model_dump()
    doc['created_at'] = doc['created_at'].isoformat()
    
    await db.users.insert_one(doc)
    return user_obj

@api_router.post("/auth/login", response_model=Token)
async def login(user_data: UserLogin):
    user = await db.users.find_one({"email": user_data.email}, {"_id": 0})
    if not user:
        raise HTTPException(status_code=401, detail="Incorrect email or password")
    
    if not verify_password(user_data.password, user['hashed_password']):
        raise HTTPException(status_code=401, detail="Incorrect email or password")
    
    access_token = create_access_token(data={"sub": user['id']})
    
    if isinstance(user.get('created_at'), str):
        user['created_at'] = datetime.fromisoformat(user['created_at'])
    
    user_obj = User(**{k: v for k, v in user.items() if k != 'hashed_password'})
    
    return Token(access_token=access_token, token_type="bearer", user=user_obj)

@api_router.get("/auth/me", response_model=User)
async def get_me(current_user: User = Depends(get_current_user)):
    return current_user

# ============ POSTS ROUTES (Notícias) ============

@api_router.get("/posts", response_model=List[Post])
async def get_posts(limit: int = 100, skip: int = 0, published: Optional[bool] = None):
    query = {}
    if published is not None:
        query['published'] = published
    
    posts = await db.posts.find(query, {"_id": 0}).sort("created_at", -1).skip(skip).limit(limit).to_list(limit)
    
    for post in posts:
        if isinstance(post.get('created_at'), str):
            post['created_at'] = datetime.fromisoformat(post['created_at'])
        if isinstance(post.get('updated_at'), str):
            post['updated_at'] = datetime.fromisoformat(post['updated_at'])
    
    return posts

@api_router.get("/posts/{slug}", response_model=Post)
async def get_post(slug: str):
    post = await db.posts.find_one({"slug": slug}, {"_id": 0})
    if not post:
        raise HTTPException(status_code=404, detail="Post not found")
    
    if isinstance(post.get('created_at'), str):
        post['created_at'] = datetime.fromisoformat(post['created_at'])
    if isinstance(post.get('updated_at'), str):
        post['updated_at'] = datetime.fromisoformat(post['updated_at'])
    
    return post

@api_router.post("/posts", response_model=Post)
async def create_post(post_data: PostCreate, current_user: User = Depends(get_current_user)):
    post_dict = post_data.model_dump()
    post_dict['slug'] = create_slug(post_data.title)
    post_dict['author_id'] = current_user.id
    post_dict['author_name'] = current_user.name
    
    post_obj = Post(**post_dict)
    doc = post_obj.model_dump()
    doc['created_at'] = doc['created_at'].isoformat()
    doc['updated_at'] = doc['updated_at'].isoformat()
    
    await db.posts.insert_one(doc)
    return post_obj

@api_router.put("/posts/{post_id}", response_model=Post)
async def update_post(post_id: str, post_data: PostCreate, current_user: User = Depends(get_current_user)):
    existing_post = await db.posts.find_one({"id": post_id}, {"_id": 0})
    if not existing_post:
        raise HTTPException(status_code=404, detail="Post not found")
    
    post_dict = post_data.model_dump()
    post_dict['slug'] = create_slug(post_data.title)
    post_dict['updated_at'] = datetime.now(timezone.utc).isoformat()
    
    await db.posts.update_one({"id": post_id}, {"$set": post_dict})
    
    updated_post = await db.posts.find_one({"id": post_id}, {"_id": 0})
    if isinstance(updated_post.get('created_at'), str):
        updated_post['created_at'] = datetime.fromisoformat(updated_post['created_at'])
    if isinstance(updated_post.get('updated_at'), str):
        updated_post['updated_at'] = datetime.fromisoformat(updated_post['updated_at'])
    
    return updated_post

@api_router.delete("/posts/{post_id}")
async def delete_post(post_id: str, current_user: User = Depends(get_current_user)):
    result = await db.posts.delete_one({"id": post_id})
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Post not found")
    return {"message": "Post deleted successfully"}

# ============ COLUMNS ROUTES (Colunas) ============

@api_router.get("/columns", response_model=List[Column])
async def get_columns(limit: int = 100, skip: int = 0, published: Optional[bool] = None):
    query = {}
    if published is not None:
        query['published'] = published
    
    columns = await db.columns.find(query, {"_id": 0}).sort("created_at", -1).skip(skip).limit(limit).to_list(limit)
    
    for column in columns:
        if isinstance(column.get('created_at'), str):
            column['created_at'] = datetime.fromisoformat(column['created_at'])
        if isinstance(column.get('updated_at'), str):
            column['updated_at'] = datetime.fromisoformat(column['updated_at'])
    
    return columns

@api_router.get("/columns/{slug}", response_model=Column)
async def get_column(slug: str):
    column = await db.columns.find_one({"slug": slug}, {"_id": 0})
    if not column:
        raise HTTPException(status_code=404, detail="Column not found")
    
    if isinstance(column.get('created_at'), str):
        column['created_at'] = datetime.fromisoformat(column['created_at'])
    if isinstance(column.get('updated_at'), str):
        column['updated_at'] = datetime.fromisoformat(column['updated_at'])
    
    return column

@api_router.post("/columns", response_model=Column)
async def create_column(column_data: ColumnCreate, current_user: User = Depends(get_current_user)):
    column_dict = column_data.model_dump()
    column_dict['slug'] = create_slug(column_data.title)
    column_dict['author_id'] = current_user.id
    column_dict['author_name'] = current_user.name
    
    column_obj = Column(**column_dict)
    doc = column_obj.model_dump()
    doc['created_at'] = doc['created_at'].isoformat()
    doc['updated_at'] = doc['updated_at'].isoformat()
    
    await db.columns.insert_one(doc)
    return column_obj

@api_router.put("/columns/{column_id}", response_model=Column)
async def update_column(column_id: str, column_data: ColumnCreate, current_user: User = Depends(get_current_user)):
    existing_column = await db.columns.find_one({"id": column_id}, {"_id": 0})
    if not existing_column:
        raise HTTPException(status_code=404, detail="Column not found")
    
    column_dict = column_data.model_dump()
    column_dict['slug'] = create_slug(column_data.title)
    column_dict['updated_at'] = datetime.now(timezone.utc).isoformat()
    
    await db.columns.update_one({"id": column_id}, {"$set": column_dict})
    
    updated_column = await db.columns.find_one({"id": column_id}, {"_id": 0})
    if isinstance(updated_column.get('created_at'), str):
        updated_column['created_at'] = datetime.fromisoformat(updated_column['created_at'])
    if isinstance(updated_column.get('updated_at'), str):
        updated_column['updated_at'] = datetime.fromisoformat(updated_column['updated_at'])
    
    return updated_column

@api_router.delete("/columns/{column_id}")
async def delete_column(column_id: str, current_user: User = Depends(get_current_user)):
    result = await db.columns.delete_one({"id": column_id})
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Column not found")
    return {"message": "Column deleted successfully"}

# ============ EVENTS ROUTES (Eventos) ============

@api_router.get("/events", response_model=List[Event])
async def get_events(limit: int = 100, skip: int = 0, published: Optional[bool] = None):
    query = {}
    if published is not None:
        query['published'] = published
    
    events = await db.events.find(query, {"_id": 0}).sort("event_date", 1).skip(skip).limit(limit).to_list(limit)
    
    for event in events:
        if isinstance(event.get('created_at'), str):
            event['created_at'] = datetime.fromisoformat(event['created_at'])
        if isinstance(event.get('updated_at'), str):
            event['updated_at'] = datetime.fromisoformat(event['updated_at'])
        if isinstance(event.get('event_date'), str):
            event['event_date'] = datetime.fromisoformat(event['event_date'])
    
    return events

@api_router.get("/events/{slug}", response_model=Event)
async def get_event(slug: str):
    event = await db.events.find_one({"slug": slug}, {"_id": 0})
    if not event:
        raise HTTPException(status_code=404, detail="Event not found")
    
    if isinstance(event.get('created_at'), str):
        event['created_at'] = datetime.fromisoformat(event['created_at'])
    if isinstance(event.get('updated_at'), str):
        event['updated_at'] = datetime.fromisoformat(event['updated_at'])
    if isinstance(event.get('event_date'), str):
        event['event_date'] = datetime.fromisoformat(event['event_date'])
    
    return event

@api_router.post("/events", response_model=Event)
async def create_event(event_data: EventCreate, current_user: User = Depends(get_current_user)):
    event_dict = event_data.model_dump()
    event_dict['slug'] = create_slug(event_data.title)
    event_dict['event_date'] = event_dict['event_date'].isoformat()
    
    event_obj = Event(**event_dict)
    doc = event_obj.model_dump()
    doc['created_at'] = doc['created_at'].isoformat()
    doc['updated_at'] = doc['updated_at'].isoformat()
    
    await db.events.insert_one(doc)
    
    # Convert back for response
    event_obj.event_date = datetime.fromisoformat(doc['event_date'])
    return event_obj

@api_router.put("/events/{event_id}", response_model=Event)
async def update_event(event_id: str, event_data: EventCreate, current_user: User = Depends(get_current_user)):
    existing_event = await db.events.find_one({"id": event_id}, {"_id": 0})
    if not existing_event:
        raise HTTPException(status_code=404, detail="Event not found")
    
    event_dict = event_data.model_dump()
    event_dict['slug'] = create_slug(event_data.title)
    event_dict['event_date'] = event_dict['event_date'].isoformat()
    event_dict['updated_at'] = datetime.now(timezone.utc).isoformat()
    
    await db.events.update_one({"id": event_id}, {"$set": event_dict})
    
    updated_event = await db.events.find_one({"id": event_id}, {"_id": 0})
    if isinstance(updated_event.get('created_at'), str):
        updated_event['created_at'] = datetime.fromisoformat(updated_event['created_at'])
    if isinstance(updated_event.get('updated_at'), str):
        updated_event['updated_at'] = datetime.fromisoformat(updated_event['updated_at'])
    if isinstance(updated_event.get('event_date'), str):
        updated_event['event_date'] = datetime.fromisoformat(updated_event['event_date'])
    
    return updated_event

@api_router.delete("/events/{event_id}")
async def delete_event(event_id: str, current_user: User = Depends(get_current_user)):
    result = await db.events.delete_one({"id": event_id})
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Event not found")
    return {"message": "Event deleted successfully"}

# ============ EDITIONS ROUTES (Edições) ============

@api_router.get("/editions", response_model=List[Edition])
async def get_editions(limit: int = 100, skip: int = 0, published: Optional[bool] = None):
    query = {}
    if published is not None:
        query['published'] = published
    
    editions = await db.editions.find(query, {"_id": 0}).sort("edition_number", -1).skip(skip).limit(limit).to_list(limit)
    
    for edition in editions:
        if isinstance(edition.get('created_at'), str):
            edition['created_at'] = datetime.fromisoformat(edition['created_at'])
        if isinstance(edition.get('updated_at'), str):
            edition['updated_at'] = datetime.fromisoformat(edition['updated_at'])
    
    return editions

@api_router.get("/editions/{slug}", response_model=Edition)
async def get_edition(slug: str):
    edition = await db.editions.find_one({"slug": slug}, {"_id": 0})
    if not edition:
        raise HTTPException(status_code=404, detail="Edition not found")
    
    if isinstance(edition.get('created_at'), str):
        edition['created_at'] = datetime.fromisoformat(edition['created_at'])
    if isinstance(edition.get('updated_at'), str):
        edition['updated_at'] = datetime.fromisoformat(edition['updated_at'])
    
    return edition

@api_router.post("/editions", response_model=Edition)
async def create_edition(edition_data: EditionCreate, current_user: User = Depends(get_current_user)):
    edition_dict = edition_data.model_dump()
    edition_dict['slug'] = create_slug(edition_data.title)
    
    edition_obj = Edition(**edition_dict)
    doc = edition_obj.model_dump()
    doc['created_at'] = doc['created_at'].isoformat()
    doc['updated_at'] = doc['updated_at'].isoformat()
    
    await db.editions.insert_one(doc)
    return edition_obj

@api_router.put("/editions/{edition_id}", response_model=Edition)
async def update_edition(edition_id: str, edition_data: EditionCreate, current_user: User = Depends(get_current_user)):
    existing_edition = await db.editions.find_one({"id": edition_id}, {"_id": 0})
    if not existing_edition:
        raise HTTPException(status_code=404, detail="Edition not found")
    
    edition_dict = edition_data.model_dump()
    edition_dict['slug'] = create_slug(edition_data.title)
    edition_dict['updated_at'] = datetime.now(timezone.utc).isoformat()
    
    await db.editions.update_one({"id": edition_id}, {"$set": edition_dict})
    
    updated_edition = await db.editions.find_one({"id": edition_id}, {"_id": 0})
    if isinstance(updated_edition.get('created_at'), str):
        updated_edition['created_at'] = datetime.fromisoformat(updated_edition['created_at'])
    if isinstance(updated_edition.get('updated_at'), str):
        updated_edition['updated_at'] = datetime.fromisoformat(updated_edition['updated_at'])
    
    return updated_edition

@api_router.delete("/editions/{edition_id}")
async def delete_edition(edition_id: str, current_user: User = Depends(get_current_user)):
    result = await db.editions.delete_one({"id": edition_id})
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Edition not found")
    return {"message": "Edition deleted successfully"}

# ============ MEDIA ROUTES (Upload de imagens) ============

@api_router.post("/media/upload", response_model=Media)
async def upload_media(file: UploadFile = File(...), current_user: User = Depends(get_current_user)):
    # Create uploads directory if it doesn't exist
    upload_dir = Path("/app/backend/uploads")
    upload_dir.mkdir(exist_ok=True)
    
    # Generate unique filename
    file_extension = Path(file.filename).suffix
    unique_filename = f"{uuid.uuid4()}{file_extension}"
    file_path = upload_dir / unique_filename
    
    # Save file
    with file_path.open("wb") as buffer:
        shutil.copyfileobj(file.file, buffer)
    
    # Create media object
    media_obj = Media(
        filename=file.filename,
        url=f"/api/media/{unique_filename}",
        uploaded_by=current_user.id
    )
    
    doc = media_obj.model_dump()
    doc['uploaded_at'] = doc['uploaded_at'].isoformat()
    
    await db.media.insert_one(doc)
    return media_obj

@api_router.get("/media", response_model=List[Media])
async def get_media(current_user: User = Depends(get_current_user)):
    media_list = await db.media.find({}, {"_id": 0}).sort("uploaded_at", -1).to_list(100)
    
    for media in media_list:
        if isinstance(media.get('uploaded_at'), str):
            media['uploaded_at'] = datetime.fromisoformat(media['uploaded_at'])
    
    return media_list

from fastapi.responses import FileResponse

@api_router.get("/media/{filename}")
async def get_media_file(filename: str):
    file_path = Path("/app/backend/uploads") / filename
    if not file_path.exists():
        raise HTTPException(status_code=404, detail="File not found")
    return FileResponse(file_path)

# ============ HOME/DASHBOARD ROUTE ============

@api_router.get("/home")
async def get_home_data():
    # Get latest post
    latest_posts = await db.posts.find({"published": True}, {"_id": 0}).sort("created_at", -1).limit(4).to_list(4)
    
    # Get latest columns
    latest_columns = await db.columns.find({"published": True}, {"_id": 0}).sort("created_at", -1).limit(3).to_list(3)
    
    # Get upcoming events
    upcoming_events = await db.events.find({"published": True}, {"_id": 0}).sort("event_date", 1).limit(3).to_list(3)
    
    # Get latest editions
    latest_editions = await db.editions.find({"published": True}, {"_id": 0}).sort("edition_number", -1).limit(3).to_list(3)
    
    # Convert datetime strings
    for post in latest_posts:
        if isinstance(post.get('created_at'), str):
            post['created_at'] = datetime.fromisoformat(post['created_at'])
        if isinstance(post.get('updated_at'), str):
            post['updated_at'] = datetime.fromisoformat(post['updated_at'])
    
    for column in latest_columns:
        if isinstance(column.get('created_at'), str):
            column['created_at'] = datetime.fromisoformat(column['created_at'])
        if isinstance(column.get('updated_at'), str):
            column['updated_at'] = datetime.fromisoformat(column['updated_at'])
    
    for event in upcoming_events:
        if isinstance(event.get('created_at'), str):
            event['created_at'] = datetime.fromisoformat(event['created_at'])
        if isinstance(event.get('updated_at'), str):
            event['updated_at'] = datetime.fromisoformat(event['updated_at'])
        if isinstance(event.get('event_date'), str):
            event['event_date'] = datetime.fromisoformat(event['event_date'])
    
    for edition in latest_editions:
        if isinstance(edition.get('created_at'), str):
            edition['created_at'] = datetime.fromisoformat(edition['created_at'])
        if isinstance(edition.get('updated_at'), str):
            edition['updated_at'] = datetime.fromisoformat(edition['updated_at'])
    
    return {
        "featured_post": latest_posts[0] if latest_posts else None,
        "recent_posts": latest_posts[1:4] if len(latest_posts) > 1 else [],
        "columns": latest_columns,
        "events": upcoming_events,
        "editions": latest_editions
    }

# Include the router in the main app
app.include_router(api_router)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=os.environ.get('CORS_ORIGINS', '*').split(','),
    allow_methods=["*"],
    allow_headers=["*"],
)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

@app.on_event("shutdown")
async def shutdown_db_client():
    client.close()
