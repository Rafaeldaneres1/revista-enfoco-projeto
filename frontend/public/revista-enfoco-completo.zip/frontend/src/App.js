import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import './App.css';
import Header from './components/Header';
import Footer from './components/Footer';

// Páginas Públicas
import Home from './pages/Home';
import About from './pages/About';
import PostsPage from './pages/PostsPage';
import SinglePost from './pages/SinglePost';
import ColumnsPage from './pages/ColumnsPage';
import SingleColumn from './pages/SingleColumn';
import EventsPage from './pages/EventsPage';
import EditionsPage from './pages/EditionsPage';

// Páginas Admin
import AdminLogin from './pages/AdminLogin';
import AdminDashboard from './pages/AdminDashboard';
import AdminPosts from './pages/AdminPosts';
import AdminPostForm from './pages/AdminPostForm';

function App() {
  return (
    <Router>
      <div className="App min-h-screen flex flex-col">
        <Header />
        <main className="flex-1">
          <Routes>
            {/* Páginas Públicas */}
            <Route path="/" element={<Home />} />
            <Route path="/quem-somos" element={<About />} />
            <Route path="/noticias" element={<PostsPage />} />
            <Route path="/noticias/:slug" element={<SinglePost />} />
            <Route path="/materia/:slug" element={<SinglePost />} />
            <Route path="/colunas" element={<ColumnsPage />} />
            <Route path="/colunas/:slug" element={<SingleColumn />} />
            <Route path="/coluna/:slug" element={<SingleColumn />} />
            <Route path="/eventos" element={<EventsPage />} />
            <Route path="/edicoes" element={<EditionsPage />} />
            <Route path="/revista" element={<EditionsPage />} />
            
            {/* Páginas Admin */}
            <Route path="/admin" element={<AdminLogin />} />
            <Route path="/admin/dashboard" element={<AdminDashboard />} />
            <Route path="/admin/posts" element={<AdminPosts />} />
            <Route path="/admin/posts/new" element={<AdminPostForm />} />
            <Route path="/admin/posts/edit/:id" element={<AdminPostForm />} />
          </Routes>
        </main>
        <Footer />
      </div>
    </Router>
  );
}

export default App;
