import React from 'react';
import { Link } from 'react-router-dom';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

const ColumnCard = ({ column }) => {
  return (
    <div className="enfoco-glass rounded-[42px] overflow-hidden group">
      {column.featured_image && (
        <div className="aspect-[5/4] overflow-hidden">
          <img 
            src={column.featured_image} 
            alt={column.title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          />
        </div>
      )}
      <div className="p-6">
        <Link to={`/colunas/${column.slug}`}>
          <h3 className="font-display text-xl md:text-2xl font-bold leading-tight mb-2 hover:text-stone transition-colors" style={{ letterSpacing: '-0.04em' }}>
            {column.title}
          </h3>
        </Link>
        <p className="text-stone text-sm leading-relaxed mb-4">
          {column.excerpt}
        </p>
        <div className="flex items-center gap-3 text-xs text-stone">
          <span>{column.author_name}</span>
          <span>•</span>
          <time>{format(new Date(column.created_at), "d 'de' MMMM, yyyy", { locale: ptBR })}</time>
        </div>
      </div>
    </div>
  );
};

export default ColumnCard;