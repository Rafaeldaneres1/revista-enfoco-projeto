import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';

const Header = () => {
  const location = useLocation();
  const isAdmin = location.pathname.startsWith('/admin');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  if (isAdmin) {
    return null;
  }

  const navItems = [
    { name: 'Início', path: '/' },
    { name: 'Quem Somos', path: '/quem-somos' },
    { name: 'Notícias', path: '/noticias' },
    { name: 'Colunas', path: '/colunas' },
    { name: 'Eventos', path: '/eventos' },
    { name: 'Revista', path: '/revista' }
  ];

  return (
    <header className="bg-white border-b border-gray-200 sticky top-0 z-50">
      <nav className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="flex justify-between items-center h-20">
          <Link to="/" className="font-display text-2xl font-medium text-charcoal tracking-tight">
            Revista Enfoco
          </Link>
          
          {/* Desktop Menu */}
          <ul className="hidden md:flex items-center space-x-8">
            {navItems.map((item) => (
              <li key={item.path}>
                <Link 
                  to={item.path}
                  className={`text-sm font-medium tracking-wide uppercase transition-colors ${
                    location.pathname === item.path 
                      ? 'text-royal-blue' 
                      : 'text-charcoal hover:text-stone'
                  }`}
                >
                  {item.name}
                </Link>
              </li>
            ))}
            <li>
              <button className="bg-royal-blue hover:bg-royal-blue-dark text-white px-6 py-2.5 text-sm font-semibold tracking-wide uppercase transition-colors">
                Assinar
              </button>
            </li>
          </ul>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden p-2 text-charcoal"
            aria-label="Menu"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              {mobileMenuOpen ? (
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              ) : (
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              )}
            </svg>
          </button>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden border-t border-gray-200 py-4">
            <ul className="space-y-4">
              {navItems.map((item) => (
                <li key={item.path}>
                  <Link
                    to={item.path}
                    onClick={() => setMobileMenuOpen(false)}
                    className={`block px-4 py-2 text-sm font-medium tracking-wide uppercase transition-colors ${
                      location.pathname === item.path 
                        ? 'text-royal-blue bg-blue-50' 
                        : 'text-charcoal hover:bg-gray-50'
                    }`}
                  >
                    {item.name}
                  </Link>
                </li>
              ))}
              <li className="px-4">
                <button className="w-full bg-royal-blue hover:bg-royal-blue-dark text-white px-6 py-2.5 text-sm font-semibold tracking-wide uppercase transition-colors">
                  Assinar
                </button>
              </li>
            </ul>
          </div>
        )}
      </nav>
    </header>
  );
};

export default Header;
