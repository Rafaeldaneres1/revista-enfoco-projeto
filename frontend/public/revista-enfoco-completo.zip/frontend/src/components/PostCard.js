import React from 'react';
import { Link } from 'react-router-dom';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

const PostCard = ({ post }) => {
  return (
    <div className="enfoco-glass rounded-[42px] overflow-hidden group">
      {post.featured_image && (
        <div className="aspect-[5/4] overflow-hidden">
          <img 
            src={post.featured_image} 
            alt={post.title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          />
        </div>
      )}
      <div className="p-6">
        <div className="flex items-center gap-2 mb-3">
          <span className="inline-flex items-center px-3 py-1 rounded-full border border-charcoal/8 bg-white/86 text-xs text-charcoal-light">
            {post.category}
          </span>
        </div>
        <Link to={`/noticias/${post.slug}`}>
          <h3 className="font-display text-xl md:text-2xl font-bold leading-tight mb-2 hover:text-stone transition-colors" style={{ letterSpacing: '-0.04em' }}>
            {post.title}
          </h3>
        </Link>
        <p className="text-stone text-sm leading-relaxed mb-4">
          {post.excerpt}
        </p>
        <div className="flex items-center gap-3 text-xs text-stone">
          <span>{post.author_name}</span>
          <span>•</span>
          <time>{format(new Date(post.created_at), "d 'de' MMMM, yyyy", { locale: ptBR })}</time>
        </div>
      </div>
    </div>
  );
};

export default PostCard;