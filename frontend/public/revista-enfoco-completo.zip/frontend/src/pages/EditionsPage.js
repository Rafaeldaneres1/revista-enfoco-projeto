import React, { useState, useEffect } from 'react';
import axios from 'axios';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;

const EditionsPage = () => {
  const [editions, setEditions] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchEditions();
  }, []);

  const fetchEditions = async () => {
    try {
      const response = await axios.get(`${BACKEND_URL}/api/editions?published=true`);
      setEditions(response.data);
    } catch (error) {
      console.error('Error fetching editions:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="text-center">
          <div className="w-12 h-12 border-2 border-charcoal/20 border-t-charcoal rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-stone text-sm">Carregando...</p>
        </div>
      </div>
    );
  }

  const latestEdition = editions[0];
  const archiveEditions = editions.slice(1);

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <div className="border-b border-gray-200 py-20">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <p className="text-xs font-sans tracking-[0.2em] uppercase text-stone mb-4">
            Acervo Digital
          </p>
          <h1 className="font-display text-6xl lg:text-7xl font-bold text-charcoal mb-6">
            Edições da<br/>
            <em className="font-serif italic font-normal">Revista</em>
          </h1>
          <p className="text-lg text-stone max-w-2xl">
            Explore todas as edições da Revista Enfoco. Conteúdo exclusivo em formato digital.
          </p>
        </div>
      </div>

      {/* Latest Edition Hero */}
      {latestEdition && (
        <div className="max-w-7xl mx-auto px-6 lg:px-8 py-20">
          <p className="text-xs font-sans tracking-[0.2em] uppercase text-royal-blue mb-8 text-center">
            Edição Mais Recente
          </p>
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div className="order-2 lg:order-1">
              <p className="text-xs font-sans tracking-[0.2em] uppercase text-stone mb-4">
                Edição #{latestEdition.edition_number} • {new Date(latestEdition.created_at).toLocaleDateString('pt-BR', { month: 'long', year: 'numeric' })}
              </p>
              <h2 className="font-display text-5xl lg:text-6xl font-bold text-charcoal mb-6 leading-tight">
                {latestEdition.title}
              </h2>
              <p className="text-lg text-stone leading-relaxed mb-8">
                {latestEdition.description}
              </p>
              <div className="flex gap-4">
                {latestEdition.pdf_url && (
                  <a 
                    href={latestEdition.pdf_url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="bg-royal-blue hover:bg-royal-blue-dark text-white px-8 py-4 text-sm font-semibold tracking-wide uppercase transition-colors inline-flex items-center gap-2"
                  >
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                    </svg>
                    Baixar PDF
                  </a>
                )}
                <button className="border-2 border-charcoal text-charcoal hover:bg-charcoal hover:text-white px-8 py-4 text-sm font-semibold tracking-wide uppercase transition-all">
                  Ver Prévia
                </button>
              </div>
            </div>
            <div className="order-1 lg:order-2">
              {latestEdition.cover_image && (
                <img 
                  src={latestEdition.cover_image}
                  alt={latestEdition.title}
                  className="w-full shadow-2xl"
                />
              )}
            </div>
          </div>
        </div>
      )}

      {/* Archive */}
      {archiveEditions.length > 0 && (
        <div className="bg-porcelain py-20">
          <div className="max-w-7xl mx-auto px-6 lg:px-8">
            <h2 className="font-display text-3xl font-bold text-charcoal mb-12">Edições Anteriores</h2>
            <div className="grid sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-8">
              {archiveEditions.map((edition) => (
                <div key={edition.id} className="group cursor-pointer">
                  <div className="bg-white mb-4 overflow-hidden">
                    {edition.cover_image ? (
                      <img 
                        src={edition.cover_image}
                        alt={edition.title}
                        className="w-full aspect-[3/4] object-cover group-hover:scale-105 transition-transform duration-700"
                      />
                    ) : (
                      <div className="w-full aspect-[3/4] bg-gray-200 flex items-center justify-center">
                        <span className="text-6xl font-bold text-gray-400">#{edition.edition_number}</span>
                      </div>
                    )}
                  </div>
                  <p className="text-xs font-sans tracking-[0.15em] uppercase text-stone mb-2">
                    Edição #{edition.edition_number}
                  </p>
                  <h3 className="font-display text-xl font-bold text-charcoal mb-2 group-hover:text-royal-blue transition-colors">
                    {edition.title}
                  </h3>
                  <p className="text-sm text-stone mb-3 line-clamp-2">
                    {edition.description}
                  </p>
                  {edition.pdf_url && (
                    <a 
                      href={edition.pdf_url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-sm text-royal-blue hover:underline flex items-center gap-1"
                    >
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                      </svg>
                      Baixar
                    </a>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {editions.length === 0 && (
        <div className="text-center py-24">
          <p className="text-stone text-lg">Nenhuma edição disponível no momento.</p>
        </div>
      )}

      {/* Subscription CTA */}
      <div className="py-20">
        <div className="max-w-4xl mx-auto px-6 lg:px-8 text-center">
          <h3 className="font-display text-4xl lg:text-5xl font-bold text-charcoal mb-6">
            Assine para receber todas as edições
          </h3>
          <p className="text-lg text-stone mb-8">
            Acesso ilimitado a todas as edições digitais e conteúdo exclusivo.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button className="bg-royal-blue hover:bg-royal-blue-dark text-white px-10 py-4 text-sm font-semibold tracking-wide uppercase transition-colors">
              Ver Planos
            </button>
            <button className="border-2 border-charcoal text-charcoal hover:bg-charcoal hover:text-white px-10 py-4 text-sm font-semibold tracking-wide uppercase transition-all">
              Saiba Mais
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EditionsPage;
