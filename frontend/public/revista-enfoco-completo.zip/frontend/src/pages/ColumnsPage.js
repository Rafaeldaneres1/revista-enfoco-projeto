import React, { useState, useEffect } from 'react';
import { columns } from '../data/mockData';

const ColumnsPage = () => {
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setTimeout(() => setLoading(false), 300);
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="text-center">
          <div className="w-12 h-12 border-2 border-charcoal/20 border-t-charcoal rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-stone text-sm">Carregando...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white">

      {/* Header */}
      <div className="border-b border-gray-200 py-20">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <p className="text-xs font-sans tracking-[0.2em] uppercase text-stone mb-4">
            Vozes Autorais
          </p>
          <h1 className="font-display text-6xl lg:text-7xl font-bold text-charcoal mb-6">
            Colunas de<br/>
            <em className="font-serif italic font-normal">Opinião</em>
          </h1>
          <p className="text-lg text-stone max-w-2xl">
            Perspectivas únicas de especialistas renomados sobre os temas que moldam nosso tempo.
          </p>
        </div>
      </div>

      {/* Columns Grid */}
      <div className="max-w-7xl mx-auto px-6 lg:px-8 py-16">
        {columns.length === 0 ? (
          <div className="text-center py-24">
            <p className="text-stone text-lg">Nenhuma coluna disponível no momento.</p>
          </div>
        ) : (
          <div className="grid md:grid-cols-2 gap-16">
            {columns.map((column) => (
              <a 
                key={column.id} 
                href={`/colunas/${column.slug}`}
                className="group"
              >
                {column.featured_image && (
                  <div className="aspect-[16/9] overflow-hidden bg-gray-100 mb-6">
                    <img 
                      src={column.featured_image}
                      alt={column.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                    />
                  </div>
                )}
                
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-10 h-10 bg-charcoal rounded-full flex items-center justify-center text-white font-bold text-sm">
                    {column.author_name.charAt(0)}
                  </div>
                  <div className="text-sm">
                    <div className="font-medium text-charcoal">{column.author_name}</div>
                    <div className="text-stone text-xs">Colunista</div>
                  </div>
                </div>

                <h2 className="font-display text-3xl lg:text-4xl font-bold text-charcoal mb-4 leading-tight group-hover:text-royal-blue transition-colors">
                  {column.title}
                </h2>
                
                <p className="text-base text-stone leading-relaxed mb-4">
                  {column.excerpt}
                </p>
                
                <div className="flex items-center text-sm text-stone">
                  <span>{new Date(column.created_at).toLocaleDateString('pt-BR', { day: 'numeric', month: 'long', year: 'numeric' })}</span>
                  <span className="mx-2">•</span>
                  <span>6 min de leitura</span>
                </div>
              </a>
            ))}
          </div>
        )}
      </div>

      {/* CTA Section */}
      <div className="bg-porcelain py-20 mt-12">
        <div className="max-w-3xl mx-auto px-6 lg:px-8 text-center">
          <h3 className="font-display text-3xl lg:text-4xl font-bold text-charcoal mb-6">
            Quer escrever para nós?
          </h3>
          <p className="text-stone mb-8">
            Estamos sempre em busca de novas vozes e perspectivas. Entre em contato para propor sua coluna.
          </p>
          <a
            href="/quem-somos"
            className="bg-royal-blue hover:bg-royal-blue-dark text-white px-8 py-4 text-sm font-semibold tracking-wide uppercase transition-colors inline-block"
          >
            Fale Conosco
          </a>
        </div>
      </div>
    </div>
  );
};

export default ColumnsPage;
