import React, { useState, useEffect } from 'react';
import { posts, columns, events, editions } from '../data/mockData';

const Home = () => {
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Simula carregamento
    setTimeout(() => setLoading(false), 500);
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="text-center">
          <div className="w-12 h-12 border-2 border-charcoal/20 border-t-charcoal rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-stone text-sm">Carregando...</p>
        </div>
      </div>
    );
  }

  const featuredPost = posts[0];
  const recentPosts = posts.slice(1, 4);
  const latestEdition = editions[0];

  return (
    <div className="min-h-screen">

      {/* Hero Section - Fullscreen */}
      {featuredPost && (
        <section className="relative h-screen flex items-center">
          <div className="absolute inset-0">
            <img 
              src={featuredPost.featured_image}
              alt={featuredPost.title}
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 hero-overlay"></div>
          </div>
          
          <div className="relative z-10 max-w-4xl mx-auto px-6 lg:px-8 text-white">
            <p className="text-xs font-sans tracking-[0.2em] uppercase mb-6 opacity-90">
              {featuredPost.category}
            </p>
            <h1 className="font-display text-6xl lg:text-7xl xl:text-8xl font-bold mb-8 leading-[0.95] text-balance">
              {featuredPost.title}
            </h1>
            <p className="text-lg lg:text-xl mb-12 max-w-2xl opacity-90 leading-relaxed">
              {featuredPost.excerpt}
            </p>
            <div className="flex gap-4">
              <a 
                href={`/noticias/${featuredPost.slug}`}
                className="bg-royal-blue hover:bg-royal-blue-dark text-white px-8 py-4 text-sm font-semibold tracking-wide uppercase transition-colors inline-block"
              >
                Ler Matéria
              </a>
              <a 
                href="/noticias"
                className="border-2 border-white text-white hover:bg-white hover:text-charcoal px-8 py-4 text-sm font-semibold tracking-wide uppercase transition-all inline-block"
              >
                Mais Notícias
              </a>
            </div>
          </div>

          <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 text-white opacity-50 animate-bounce">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
            </svg>
          </div>
        </section>
      )}

      {/* Featured Edition Section */}
      {latestEdition && (
        <section className="max-w-7xl mx-auto px-6 lg:px-8 py-24">
          <div className="text-center mb-12">
            <p className="text-xs font-sans tracking-[0.2em] uppercase text-stone mb-3">
              Em Destaque
            </p>
            <h2 className="font-display text-5xl lg:text-6xl font-bold text-charcoal">
              Edição Atual
            </h2>
          </div>

          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div>
              <img 
                src={latestEdition.cover_image}
                alt={latestEdition.title}
                className="w-full shadow-2xl"
              />
            </div>
            <div>
              <p className="text-xs font-sans tracking-[0.2em] uppercase text-royal-blue mb-4">
                Edição #{latestEdition.edition_number}
              </p>
              <h3 className="font-display text-4xl lg:text-5xl font-bold text-charcoal mb-6 leading-tight">
                {latestEdition.title}
              </h3>
              <p className="text-base text-stone leading-relaxed mb-8">
                {latestEdition.description}
              </p>
              <a
                href="/revista"
                className="bg-royal-blue hover:bg-royal-blue-dark text-white px-8 py-4 text-sm font-semibold tracking-wide uppercase transition-colors inline-block"
              >
                Ver Edição
              </a>
            </div>
          </div>
        </section>
      )}

      {/* Articles Section */}
      {recentPosts.length > 0 && (
        <section className="bg-porcelain py-24">
          <div className="max-w-7xl mx-auto px-6 lg:px-8">
            <div className="mb-16">
              <p className="text-xs font-sans tracking-[0.2em] uppercase text-stone mb-3">
                Leitura Recomendada
              </p>
              <div className="flex justify-between items-end">
                <h2 className="font-display text-5xl lg:text-6xl font-bold text-charcoal">
                  Artigos em<br/>
                  <em className="font-serif italic font-normal">Destaque</em>
                </h2>
                <a href="/noticias" className="text-sm tracking-[0.1em] uppercase text-charcoal hover:text-royal-blue transition-colors flex items-center gap-2">
                  Ver Todos
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
                  </svg>
                </a>
              </div>
            </div>
            
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {recentPosts.map((post) => (
                <a key={post.id} href={`/noticias/${post.slug}`} className="group">
                  <div className="aspect-[3/4] overflow-hidden bg-gray-100 mb-6">
                    <img 
                      src={post.featured_image}
                      alt={post.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                    />
                  </div>
                  <p className="text-xs font-sans tracking-[0.15em] uppercase text-royal-blue mb-3">
                    {post.category}
                  </p>
                  <h3 className="font-display text-2xl font-bold text-charcoal mb-3 leading-tight group-hover:text-royal-blue transition-colors">
                    {post.title}
                  </h3>
                  <p className="text-sm text-stone leading-relaxed mb-4 line-clamp-3">
                    {post.excerpt}
                  </p>
                  <div className="flex items-center text-xs text-stone">
                    <span>{post.author_name}</span>
                    <span className="mx-2">•</span>
                    <span>8 min</span>
                  </div>
                </a>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Newsletter Section */}
      <section className="py-24 bg-charcoal text-white">
        <div className="max-w-4xl mx-auto px-6 lg:px-8 text-center">
          <h2 className="font-display text-4xl lg:text-5xl font-bold mb-6">
            Receba nossa Newsletter
          </h2>
          <p className="text-lg text-white/70 mb-12 max-w-2xl mx-auto">
            Toda semana, as melhores histórias, análises e entrevistas direto no seu email.
          </p>
          <form className="flex flex-col sm:flex-row gap-4 max-w-xl mx-auto">
            <input 
              type="email" 
              placeholder="Seu melhor email"
              className="flex-1 px-6 py-4 bg-white/10 border border-white/20 text-white placeholder:text-white/50 focus:outline-none focus:border-white/40 transition-colors"
            />
            <button className="bg-royal-blue hover:bg-royal-blue-dark text-white px-8 py-4 text-sm font-semibold tracking-wide uppercase transition-colors">
              Inscrever
            </button>
          </form>
        </div>
      </section>
    </div>
  );
};

export default Home;
