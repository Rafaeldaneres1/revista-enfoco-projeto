import React, { useState, useEffect } from 'react';
import axios from 'axios';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;

const EventsPage = () => {
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchEvents();
  }, []);

  const fetchEvents = async () => {
    try {
      const response = await axios.get(`${BACKEND_URL}/api/events?published=true`);
      setEvents(response.data);
    } catch (error) {
      console.error('Error fetching events:', error);
    } finally {
      setLoading(false);
    }
  };

  const upcomingEvents = events.filter(e => new Date(e.event_date) >= new Date());
  const pastEvents = events.filter(e => new Date(e.event_date) < new Date());

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="text-center">
          <div className="w-12 h-12 border-2 border-charcoal/20 border-t-charcoal rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-stone text-sm">Carregando...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <div className="border-b border-gray-200 py-20">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <p className="text-xs font-sans tracking-[0.2em] uppercase text-stone mb-4">
            Agenda Cultural
          </p>
          <h1 className="font-display text-6xl lg:text-7xl font-bold text-charcoal mb-6">
            Eventos e<br/>
            <em className="font-serif italic font-normal">Experiências</em>
          </h1>
          <p className="text-lg text-stone max-w-2xl">
            Encontros exclusivos, palestras e experiências culturais curadas pela Revista Enfoco.
          </p>
        </div>
      </div>

      {/* Upcoming Events */}
      {upcomingEvents.length > 0 && (
        <div className="max-w-7xl mx-auto px-6 lg:px-8 py-20">
          <h2 className="font-display text-3xl font-bold text-charcoal mb-12">Próximos Eventos</h2>
          <div className="space-y-8">
            {upcomingEvents.map((event) => {
              const eventDate = new Date(event.event_date);
              return (
                <div key={event.id} className="border border-gray-200 hover:border-charcoal transition-colors group">
                  <div className="grid md:grid-cols-[200px_1fr] gap-0">
                    <div className="bg-charcoal text-white p-8 flex flex-col items-center justify-center">
                      <div className="text-5xl font-bold mb-2">{eventDate.getDate()}</div>
                      <div className="text-sm uppercase tracking-wide">
                        {eventDate.toLocaleDateString('pt-BR', { month: 'short' })}
                      </div>
                      <div className="text-xs opacity-60 mt-1">
                        {eventDate.getFullYear()}
                      </div>
                    </div>
                    <div className="p-8">
                      <p className="text-xs font-sans tracking-[0.15em] uppercase text-royal-blue mb-3">
                        {eventDate.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}
                      </p>
                      <h3 className="font-display text-3xl font-bold text-charcoal mb-3 group-hover:text-royal-blue transition-colors">
                        {event.title}
                      </h3>
                      {event.location && (
                        <p className="text-sm text-stone mb-4 flex items-center gap-2">
                          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                          </svg>
                          {event.location}
                        </p>
                      )}
                      <p className="text-base text-stone leading-relaxed mb-6">
                        {event.description}
                      </p>
                      <button className="bg-royal-blue hover:bg-royal-blue-dark text-white px-6 py-3 text-sm font-semibold tracking-wide uppercase transition-colors">
                        Reservar Lugar
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Past Events */}
      {pastEvents.length > 0 && (
        <div className="bg-porcelain py-20">
          <div className="max-w-7xl mx-auto px-6 lg:px-8">
            <h2 className="font-display text-3xl font-bold text-charcoal mb-12">Eventos Anteriores</h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {pastEvents.map((event) => {
                const eventDate = new Date(event.event_date);
                return (
                  <div key={event.id} className="bg-white p-6 group">
                    <div className="flex items-center gap-4 mb-4">
                      <div className="bg-charcoal text-white w-16 h-16 flex flex-col items-center justify-center">
                        <div className="text-2xl font-bold">{eventDate.getDate()}</div>
                        <div className="text-xs uppercase">{eventDate.toLocaleDateString('pt-BR', { month: 'short' })}</div>
                      </div>
                      <div>
                        <h3 className="font-display text-xl font-bold text-charcoal group-hover:text-royal-blue transition-colors">
                          {event.title}
                        </h3>
                        {event.location && (
                          <p className="text-xs text-stone">{event.location}</p>
                        )}
                      </div>
                    </div>
                    <p className="text-sm text-stone line-clamp-3">
                      {event.description}
                    </p>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {events.length === 0 && (
        <div className="text-center py-24">
          <p className="text-stone text-lg">Nenhum evento disponível no momento.</p>
        </div>
      )}

      {/* Newsletter CTA */}
      <div className="py-20 bg-charcoal text-white">
        <div className="max-w-3xl mx-auto px-6 lg:px-8 text-center">
          <h3 className="font-display text-3xl lg:text-4xl font-bold mb-6">
            Receba os avisos de novos eventos
          </h3>
          <p className="text-white/70 mb-8">
            Seja o primeiro a saber sobre nossos próximos encontros exclusivos.
          </p>
          <form className="flex flex-col sm:flex-row gap-4 max-w-lg mx-auto">
            <input 
              type="email" 
              placeholder="Seu melhor email"
              className="flex-1 px-6 py-4 bg-white/10 border border-white/20 text-white placeholder:text-white/50 focus:outline-none focus:border-white/40 transition-colors"
            />
            <button className="bg-royal-blue hover:bg-royal-blue-dark text-white px-8 py-4 text-sm font-semibold tracking-wide uppercase transition-colors">
              Inscrever
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default EventsPage;
