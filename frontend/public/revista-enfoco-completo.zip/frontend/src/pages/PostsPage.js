import React, { useState, useEffect } from 'react';
import { posts } from '../data/mockData';

const PostsPage = () => {
  const [loading, setLoading] = useState(true);
  const [selectedCategory, setSelectedCategory] = useState('Todas');

  const categories = ['Todas', 'Cultura', 'Tecnologia', 'Moda', 'Gastronomia'];

  useEffect(() => {
    setTimeout(() => setLoading(false), 300);
  }, []);

  const filteredPosts = selectedCategory === 'Todas' 
    ? posts 
    : posts.filter(post => post.category === selectedCategory);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="text-center">
          <div className="w-12 h-12 border-2 border-charcoal/20 border-t-charcoal rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-stone text-sm">Carregando...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white">

      {/* Header */}
      <div className="border-b border-gray-200 py-20">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <p className="text-xs font-sans tracking-[0.2em] uppercase text-stone mb-4">
            Leitura Recomendada
          </p>
          <h1 className="font-display text-6xl lg:text-7xl font-bold text-charcoal mb-6">
            Notícias e<br/>
            <em className="font-serif italic font-normal">Artigos</em>
          </h1>
        </div>
      </div>

      {/* Filters */}
      <div className="border-b border-gray-200 sticky top-20 bg-white z-40">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="flex gap-8 overflow-x-auto py-6 scrollbar-hide">
            {categories.map(category => (
              <button
                key={category}
                onClick={() => setSelectedCategory(category)}
                className={`text-sm font-sans tracking-[0.1em] uppercase whitespace-nowrap transition-colors pb-2 border-b-2 ${
                  selectedCategory === category
                    ? 'text-charcoal border-charcoal'
                    : 'text-stone border-transparent hover:text-charcoal'
                }`}
              >
                {category}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Articles Grid */}
      <div className="max-w-7xl mx-auto px-6 lg:px-8 py-16">
        {filteredPosts.length === 0 ? (
          <div className="text-center py-24">
            <p className="text-stone text-lg">Nenhuma notícia encontrada nesta categoria.</p>
          </div>
        ) : (
          <div className="space-y-24">
            {filteredPosts.map((post, i) => (
              <a 
                key={post.id} 
                href={`/noticias/${post.slug}`}
                className={`grid lg:grid-cols-2 gap-12 items-center group ${i % 2 === 1 ? 'lg:flex-row-reverse' : ''}`}
              >
                <div className={`${i % 2 === 1 ? 'lg:order-2' : ''}`}>
                  <div className="aspect-[4/3] overflow-hidden bg-gray-100">
                    <img 
                      src={post.featured_image}
                      alt={post.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                    />
                  </div>
                </div>
                <div className={`${i % 2 === 1 ? 'lg:order-1' : ''}`}>
                  <p className="text-xs font-sans tracking-[0.15em] uppercase text-royal-blue mb-4">
                    {post.category}
                  </p>
                  <h2 className="font-display text-4xl lg:text-5xl font-bold text-charcoal mb-6 leading-tight group-hover:text-royal-blue transition-colors">
                    {post.title}
                  </h2>
                  <p className="text-base text-stone leading-relaxed mb-6">
                    {post.excerpt}
                  </p>
                  <div className="flex items-center text-sm text-stone">
                    <span className="font-medium text-charcoal">{post.author_name}</span>
                    <span className="mx-3">•</span>
                    <span>{new Date(post.created_at).toLocaleDateString('pt-BR', { day: 'numeric', month: 'long', year: 'numeric' })}</span>
                    <span className="mx-3">•</span>
                    <span>8 min de leitura</span>
                  </div>
                </div>
              </a>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default PostsPage;
