import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;

const AdminPosts = () => {
  const navigate = useNavigate();
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);
  const token = localStorage.getItem('token');

  useEffect(() => {
    if (!token) {
      navigate('/admin');
      return;
    }

    fetchPosts();
  }, [token, navigate]);

  const fetchPosts = async () => {
    try {
      const response = await axios.get(`${BACKEND_URL}/api/posts`);
      setPosts(response.data);
    } catch (error) {
      console.error('Error fetching posts:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (postId) => {
    if (!window.confirm('Tem certeza que deseja deletar esta notícia?')) {
      return;
    }

    try {
      await axios.delete(`${BACKEND_URL}/api/posts/${postId}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      fetchPosts();
    } catch (error) {
      console.error('Error deleting post:', error);
      alert('Erro ao deletar notícia');
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-charcoal font-display text-xl">Carregando...</div>
      </div>
    );
  }

  return (
    <div className="pb-16">
      <div className="max-w-7xl mx-auto px-4 mt-6">
        <div className="enfoco-glass rounded-[42px] p-8 md:p-10 mb-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="font-display text-4xl font-bold">Notícias</h1>
              <p className="text-stone mt-2">Gerenciar notícias e matérias</p>
            </div>
            <div className="flex gap-3">
              <Link to="/admin/dashboard" className="px-4 py-2 rounded-full border border-charcoal/16 text-sm hover:bg-white/78 transition-colors">
                Voltar
              </Link>
              <Link to="/admin/posts/new" className="px-4 py-2 rounded-full bg-charcoal text-white text-sm hover:bg-charcoal-light transition-colors">
                Nova Notícia
              </Link>
            </div>
          </div>
        </div>

        {posts.length > 0 ? (
          <div className="space-y-4">
            {posts.map(post => (
              <div key={post.id} className="enfoco-glass rounded-[28px] p-6">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <span className="inline-flex items-center px-3 py-1 rounded-full border border-charcoal/8 bg-white/86 text-xs text-charcoal-light">
                        {post.category}
                      </span>
                      <span className={`inline-flex items-center px-3 py-1 rounded-full text-xs ${
                        post.published ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'
                      }`}>
                        {post.published ? 'Publicado' : 'Rascunho'}
                      </span>
                    </div>
                    <h2 className="font-display text-2xl font-bold mb-2">{post.title}</h2>
                    <p className="text-stone text-sm mb-3">{post.excerpt}</p>
                    <div className="flex items-center gap-3 text-xs text-stone">
                      <span>{post.author_name}</span>
                      <span>•</span>
                      <time>{format(new Date(post.created_at), "d 'de' MMMM, yyyy", { locale: ptBR })}</time>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Link 
                      to={`/admin/posts/edit/${post.id}`}
                      className="px-4 py-2 rounded-full border border-charcoal/16 text-sm hover:bg-white/78 transition-colors"
                    >
                      Editar
                    </Link>
                    <button 
                      onClick={() => handleDelete(post.id)}
                      className="px-4 py-2 rounded-full bg-red-500 text-white text-sm hover:bg-red-600 transition-colors"
                    >
                      Deletar
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="enfoco-glass rounded-[42px] p-10 text-center">
            <p className="text-stone mb-4">Nenhuma notícia criada ainda.</p>
            <Link 
              to="/admin/posts/new"
              className="inline-flex items-center px-6 py-3 rounded-full bg-charcoal text-white font-semibold hover:bg-charcoal-light transition-colors"
            >
              Criar Primeira Notícia
            </Link>
          </div>
        )}
      </div>
    </div>
  );
};

export default AdminPosts;