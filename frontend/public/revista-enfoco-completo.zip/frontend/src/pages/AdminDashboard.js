import React from 'react';
import { Link } from 'react-router-dom';

const AdminDashboard = () => {
  const user = JSON.parse(localStorage.getItem('user') || '{}');

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    window.location.href = '/admin';
  };

  return (
    <div className="min-h-screen pb-16">
      <div className="max-w-7xl mx-auto px-4 mt-6">
        <div className="enfoco-glass rounded-[42px] p-8 md:p-10 mb-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="font-display text-4xl font-bold">Dashboard</h1>
              <p className="text-stone mt-2">Bem-vindo, {user.name}!</p>
            </div>
            <div className="flex gap-3">
              <Link to="/" className="px-4 py-2 rounded-full border border-charcoal/16 text-sm hover:bg-white/78 transition-colors">
                Ver Site
              </Link>
              <button 
                onClick={handleLogout}
                className="px-4 py-2 rounded-full bg-charcoal text-white text-sm hover:bg-charcoal-light transition-colors"
              >
                Sair
              </button>
            </div>
          </div>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-5">
          <Link to="/admin/posts" className="enfoco-glass rounded-[28px] p-6 hover:shadow-enfoco-card transition-shadow">
            <h2 className="font-display text-2xl font-bold mb-2">Notícias</h2>
            <p className="text-stone text-sm">Gerenciar notícias e matérias</p>
          </Link>

          <Link to="/admin/columns" className="enfoco-glass rounded-[28px] p-6 hover:shadow-enfoco-card transition-shadow">
            <h2 className="font-display text-2xl font-bold mb-2">Colunas</h2>
            <p className="text-stone text-sm">Gerenciar colunas de autores</p>
          </Link>

          <Link to="/admin/events" className="enfoco-glass rounded-[28px] p-6 hover:shadow-enfoco-card transition-shadow">
            <h2 className="font-display text-2xl font-bold mb-2">Eventos</h2>
            <p className="text-stone text-sm">Gerenciar agenda de eventos</p>
          </Link>

          <Link to="/admin/editions" className="enfoco-glass rounded-[28px] p-6 hover:shadow-enfoco-card transition-shadow">
            <h2 className="font-display text-2xl font-bold mb-2">Edições</h2>
            <p className="text-stone text-sm">Gerenciar edições da revista</p>
          </Link>
        </div>

        <div className="mt-6 enfoco-glass rounded-[42px] p-8">
          <h2 className="font-display text-2xl font-bold mb-4">Início Rápido</h2>
          <div className="space-y-3">
            <p className="text-stone">1. Crie sua primeira notícia em <Link to="/admin/posts/new" className="text-charcoal font-semibold hover:underline">Notícias</Link></p>
            <p className="text-stone">2. Adicione uma coluna em <Link to="/admin/columns/new" className="text-charcoal font-semibold hover:underline">Colunas</Link></p>
            <p className="text-stone">3. Cadastre um evento em <Link to="/admin/events/new" className="text-charcoal font-semibold hover:underline">Eventos</Link></p>
            <p className="text-stone">4. Publique uma edição em <Link to="/admin/editions/new" className="text-charcoal font-semibold hover:underline">Edições</Link></p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;