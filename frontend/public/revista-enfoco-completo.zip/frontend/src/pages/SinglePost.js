import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { posts } from '../data/mockData';

const SinglePost = () => {
  const { slug } = useParams();
  const [post, setPost] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const foundPost = posts.find(p => p.slug === slug);
    setPost(foundPost);
    setTimeout(() => setLoading(false), 300);
  }, [slug]);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="text-center">
          <div className="w-12 h-12 border-2 border-charcoal/20 border-t-charcoal rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-stone text-sm">Carregando...</p>
        </div>
      </div>
    );
  }

  if (!post) {
    return (
      <div className="min-h-[60vh] flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-charcoal mb-4">Matéria não encontrada</h2>
          <Link to="/noticias" className="text-royal-blue hover:underline">
            Voltar para notícias
          </Link>
        </div>
      </div>
    );
  }

  return (
    <article className="min-h-screen bg-white">

      {/* Hero Image */}
      {post.featured_image && (
        <div className="relative h-[70vh] bg-gray-100">
          <img 
            src={post.featured_image} 
            alt={post.title}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-white"></div>
        </div>
      )}

      {/* Article Content */}
      <div className="max-w-4xl mx-auto px-6 lg:px-8 -mt-32 relative z-10">
        <div className="bg-white pt-12">
          <div className="max-w-2xl mx-auto">
            <Link 
              to="/noticias" 
              className="inline-flex items-center text-sm text-stone hover:text-charcoal mb-12 transition-colors uppercase tracking-wide"
            >
              <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
              </svg>
              Voltar
            </Link>

            <p className="text-xs font-sans tracking-[0.15em] uppercase text-royal-blue mb-6">
              {post.category}
            </p>

            <h1 className="font-display text-5xl lg:text-6xl font-bold text-charcoal mb-8 leading-[1.1]">
              {post.title}
            </h1>

            <p className="text-xl text-stone mb-12 leading-relaxed">
              {post.excerpt}
            </p>

            <div className="flex items-center gap-4 pb-12 mb-12 border-b border-gray-200">
              <div className="w-12 h-12 bg-charcoal rounded-full flex items-center justify-center text-white font-bold">
                {post.author_name.charAt(0)}
              </div>
              <div>
                <div className="font-medium text-charcoal">{post.author_name}</div>
                <div className="text-sm text-stone">
                  {new Date(post.created_at).toLocaleDateString('pt-BR', { 
                    day: 'numeric', 
                    month: 'long', 
                    year: 'numeric' 
                  })} • 8 min de leitura
                </div>
              </div>
            </div>

            <div className="prose prose-lg max-w-none">
              <div className="text-lg leading-relaxed text-charcoal whitespace-pre-wrap">
                {post.content}
              </div>
            </div>

            {/* Share */}
            <div className="mt-16 pt-12 border-t border-gray-200">
              <p className="text-xs font-sans tracking-[0.15em] uppercase text-stone mb-6">
                Compartilhar
              </p>
              <div className="flex gap-4">
                <button className="w-12 h-12 border border-gray-200 flex items-center justify-center hover:border-charcoal transition-colors">
                  <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M24 4.557c-.883.392-1.832.656-2.828.775 1.017-.609 1.798-1.574 2.165-2.724-.951.564-2.005.974-3.127 1.195-.897-.957-2.178-1.555-3.594-1.555-3.179 0-5.515 2.966-4.797 6.045-4.091-.205-7.719-2.165-10.148-5.144-1.29 2.213-.669 5.108 1.523 6.574-.806-.026-1.566-.247-2.229-.616-.054 2.281 1.581 4.415 3.949 4.89-.693.188-1.452.232-2.224.084.626 1.956 2.444 3.379 4.6 3.419-2.07 1.623-4.678 2.348-7.29 2.04 2.179 1.397 4.768 2.212 7.548 2.212 9.142 0 14.307-7.721 13.995-14.646.962-.695 1.797-1.562 2.457-2.549z"/>
                  </svg>
                </button>
                <button className="w-12 h-12 border border-gray-200 flex items-center justify-center hover:border-charcoal transition-colors">
                  <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M9 8h-3v4h3v12h5v-12h3.642l.358-4h-4v-1.667c0-.955.192-1.333 1.115-1.333h2.885v-5h-3.808c-3.596 0-5.192 1.583-5.192 4.615v3.385z"/>
                  </svg>
                </button>
                <button className="w-12 h-12 border border-gray-200 flex items-center justify-center hover:border-charcoal transition-colors">
                  <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M4.98 3.5c0 1.381-1.11 2.5-2.48 2.5s-2.48-1.119-2.48-2.5c0-1.38 1.11-2.5 2.48-2.5s2.48 1.12 2.48 2.5zm.02 4.5h-5v16h5v-16zm7.982 0h-4.968v16h4.969v-8.399c0-4.67 6.029-5.052 6.029 0v8.399h4.988v-10.131c0-7.88-8.922-7.593-11.018-3.714v-2.155z"/>
                  </svg>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Newsletter CTA */}
      <div className="mt-24 py-20 bg-porcelain">
        <div className="max-w-3xl mx-auto px-6 lg:px-8 text-center">
          <h3 className="font-display text-3xl lg:text-4xl font-bold text-charcoal mb-6">
            Gostou deste artigo?
          </h3>
          <p className="text-stone mb-8">
            Receba conteúdos como este toda semana no seu email.
          </p>
          <form className="flex flex-col sm:flex-row gap-4 max-w-lg mx-auto">
            <input 
              type="email" 
              placeholder="Seu melhor email"
              className="flex-1 px-6 py-4 border border-gray-200 focus:outline-none focus:border-charcoal transition-colors"
            />
            <button className="bg-royal-blue hover:bg-royal-blue-dark text-white px-8 py-4 text-sm font-semibold tracking-wide uppercase transition-colors">
              Inscrever
            </button>
          </form>
        </div>
      </div>
    </article>
  );
};

export default SinglePost;
