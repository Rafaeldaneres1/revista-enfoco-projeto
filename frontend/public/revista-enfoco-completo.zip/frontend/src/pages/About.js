import React from 'react';
import { teamMembers } from '../data/mockData';

const About = () => {
  return (
    <div className="min-h-screen bg-white">

      {/* Hero */}
      <div className="relative h-[50vh] bg-gray-100">
        <img 
          src="https://images.unsplash.com/photo-1497366216548-37526070297c?w=1920"
          alt="Sobre"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-charcoal/50"></div>
        <div className="absolute inset-0 flex items-center justify-center">
          <h1 className="font-display text-6xl lg:text-7xl font-bold text-white text-center">
            Sobre a<br/>
            <em className="font-serif italic font-normal">Revista Enfoco</em>
          </h1>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-4xl mx-auto px-6 lg:px-8 py-20">
        <div className="max-w-3xl mx-auto">
          <p className="text-xs font-sans tracking-[0.2em] uppercase text-stone mb-8 text-center">
            Nossa História
          </p>

          <div className="space-y-8 text-lg text-stone leading-relaxed">
            <p className="text-2xl text-charcoal font-light leading-relaxed">
              A <strong className="font-semibold text-charcoal">Revista Enfoco</strong> é uma publicação digital 
              dedicada a explorar as tendências que moldam cultura, moda, design e estilo de vida contemporâneo.
            </p>

            <p>
              Fundada com o propósito de trazer um olhar atento e profundo sobre os temas que definem 
              nosso tempo, reunimos as vozes mais relevantes em diversas áreas do conhecimento e da criação.
            </p>

            <p>
              Nosso compromisso é com o jornalismo de excelência, oferecendo reportagens investigativas, 
              ensaios visuais, entrevistas exclusivas e análises que vão além da superfície.
            </p>

            <div className="py-12 my-12 border-y border-gray-200">
              <h2 className="font-display text-4xl font-bold text-charcoal mb-6 text-center">
                Nossa Missão
              </h2>
              <p className="text-center text-xl">
                Informar, inspirar e provocar reflexão através de conteúdo de qualidade, 
                mantendo sempre a integridade editorial e o compromisso com a verdade.
              </p>
            </div>

            <h2 className="font-display text-3xl font-bold text-charcoal mt-16 mb-6">
              Nossos Valores
            </h2>
            <ul className="space-y-4">
              <li className="flex items-start gap-3">
                <svg className="w-6 h-6 text-royal-blue flex-shrink-0 mt-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
                <span><strong className="text-charcoal">Independência Editorial:</strong> Nosso compromisso é com a verdade e a qualidade, não com interesses particulares</span>
              </li>
              <li className="flex items-start gap-3">
                <svg className="w-6 h-6 text-royal-blue flex-shrink-0 mt-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
                <span><strong className="text-charcoal">Diversidade:</strong> Valorizamos diferentes perspectivas e vozes plurais</span>
              </li>
              <li className="flex items-start gap-3">
                <svg className="w-6 h-6 text-royal-blue flex-shrink-0 mt-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
                <span><strong className="text-charcoal">Excelência:</strong> Buscamos sempre o mais alto padrão de qualidade jornalística</span>
              </li>
              <li className="flex items-start gap-3">
                <svg className="w-6 h-6 text-royal-blue flex-shrink-0 mt-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
                <span><strong className="text-charcoal">Inovação:</strong> Abraçamos novas formas de contar histórias sem perder nossa essência</span>
              </li>
            </ul>
          </div>
        </div>
      </div>

      {/* Team Section */}
      <div className="bg-porcelain py-20">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="font-display text-4xl font-bold text-charcoal mb-4">
              Nossa Equipe
            </h2>
            <p className="text-lg text-stone max-w-2xl mx-auto">
              Profissionais dedicados a trazer o melhor conteúdo para nossos leitores
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-12">
            {teamMembers.map((member) => (
              <div key={member.id} className="text-center">
                <div className="mb-6">
                  <img 
                    src={member.photo}
                    alt={member.name}
                    className="w-48 h-48 rounded-full object-cover mx-auto"
                  />
                </div>
                <h3 className="font-display text-2xl font-bold text-charcoal mb-2">
                  {member.name}
                </h3>
                <p className="text-xs font-sans tracking-[0.15em] uppercase text-royal-blue mb-4">
                  {member.role}
                </p>
                <p className="text-sm text-stone leading-relaxed">
                  {member.bio}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Contact Section */}
      <div className="py-20">
        <div className="max-w-4xl mx-auto px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="font-display text-4xl font-bold text-charcoal mb-6">
              Entre em Contato
            </h2>
            <p className="text-lg text-stone">
              Tem alguma dúvida, sugestão ou quer colaborar conosco?
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8 max-w-2xl mx-auto">
            <div className="bg-porcelain p-8 text-center">
              <svg className="w-12 h-12 text-royal-blue mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
              </svg>
              <h3 className="text-xs font-sans tracking-[0.15em] uppercase text-stone mb-3">Email</h3>
              <a href="mailto:contato@revistaenfoco.com" className="text-lg text-royal-blue hover:underline">
                contato@revistaenfoco.com
              </a>
            </div>

            <div className="bg-porcelain p-8 text-center">
              <svg className="w-12 h-12 text-royal-blue mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
              </svg>
              <h3 className="text-xs font-sans tracking-[0.15em] uppercase text-stone mb-3">Telefone</h3>
              <a href="tel:+551112345678" className="text-lg text-charcoal hover:text-royal-blue transition-colors">
                +55 (11) 1234-5678
              </a>
            </div>
          </div>

          <div className="mt-12 text-center">
            <h3 className="text-xs font-sans tracking-[0.15em] uppercase text-stone mb-6">Redes Sociais</h3>
            <div className="flex justify-center gap-4">
              <a href="#" className="w-12 h-12 border border-charcoal flex items-center justify-center hover:bg-charcoal hover:text-white transition-colors">
                <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M24 4.557c-.883.392-1.832.656-2.828.775 1.017-.609 1.798-1.574 2.165-2.724-.951.564-2.005.974-3.127 1.195-.897-.957-2.178-1.555-3.594-1.555-3.179 0-5.515 2.966-4.797 6.045-4.091-.205-7.719-2.165-10.148-5.144-1.29 2.213-.669 5.108 1.523 6.574-.806-.026-1.566-.247-2.229-.616-.054 2.281 1.581 4.415 3.949 4.89-.693.188-1.452.232-2.224.084.626 1.956 2.444 3.379 4.6 3.419-2.07 1.623-4.678 2.348-7.29 2.04 2.179 1.397 4.768 2.212 7.548 2.212 9.142 0 14.307-7.721 13.995-14.646.962-.695 1.797-1.562 2.457-2.549z"/>
                </svg>
              </a>
              <a href="#" className="w-12 h-12 border border-charcoal flex items-center justify-center hover:bg-charcoal hover:text-white transition-colors">
                <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/>
                </svg>
              </a>
              <a href="#" className="w-12 h-12 border border-charcoal flex items-center justify-center hover:bg-charcoal hover:text-white transition-colors">
                <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M4.98 3.5c0 1.381-1.11 2.5-2.48 2.5s-2.48-1.119-2.48-2.5c0-1.38 1.11-2.5 2.48-2.5s2.48 1.12 2.48 2.5zm.02 4.5h-5v16h5v-16zm7.982 0h-4.968v16h4.969v-8.399c0-4.67 6.029-5.052 6.029 0v8.399h4.988v-10.131c0-7.88-8.922-7.593-11.018-3.714v-2.155z"/>
                </svg>
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default About;
