import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import axios from 'axios';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;

const SingleColumn = () => {
  const { slug } = useParams();
  const [column, setColumn] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchColumn();
  }, [slug]);

  const fetchColumn = async () => {
    try {
      const response = await axios.get(`${BACKEND_URL}/api/columns/${slug}`);
      setColumn(response.data);
    } catch (error) {
      console.error('Error fetching column:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="text-center">
          <div className="w-12 h-12 border-2 border-charcoal/20 border-t-charcoal rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-stone text-sm">Carregando...</p>
        </div>
      </div>
    );
  }

  if (!column) {
    return (
      <div className="min-h-[60vh] flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-charcoal mb-4">Coluna não encontrada</h2>
          <Link to="/colunas" className="text-royal-blue hover:underline">
            Voltar para colunas
          </Link>
        </div>
      </div>
    );
  }

  return (
    <article className="min-h-screen bg-white">
      {/* Hero Image */}
      {column.featured_image && (
        <div className="relative h-[60vh] bg-gray-100">
          <img 
            src={column.featured_image} 
            alt={column.title}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-white"></div>
        </div>
      )}

      {/* Column Content */}
      <div className="max-w-4xl mx-auto px-6 lg:px-8 -mt-32 relative z-10">
        <div className="bg-white pt-12">
          <div className="max-w-2xl mx-auto">
            <Link 
              to="/colunas" 
              className="inline-flex items-center text-sm text-stone hover:text-charcoal mb-12 transition-colors uppercase tracking-wide"
            >
              <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
              </svg>
              Voltar
            </Link>

            <p className="text-xs font-sans tracking-[0.15em] uppercase text-royal-blue mb-6">
              Coluna de Opinião
            </p>

            <h1 className="font-display text-5xl lg:text-6xl font-bold text-charcoal mb-8 leading-[1.1]">
              {column.title}
            </h1>

            <p className="text-xl text-stone mb-12 leading-relaxed">
              {column.excerpt}
            </p>

            <div className="flex items-center gap-4 pb-12 mb-12 border-b border-gray-200">
              <div className="w-16 h-16 bg-charcoal rounded-full flex items-center justify-center text-white font-bold text-xl">
                {column.author_name.charAt(0)}
              </div>
              <div>
                <div className="font-medium text-charcoal text-lg">{column.author_name}</div>
                <div className="text-sm text-stone">
                  Colunista • {new Date(column.created_at).toLocaleDateString('pt-BR', { 
                    day: 'numeric', 
                    month: 'long', 
                    year: 'numeric' 
                  })}
                </div>
              </div>
            </div>

            <div className="prose prose-lg max-w-none">
              <div className="text-lg leading-relaxed text-charcoal whitespace-pre-wrap">
                {column.content}
              </div>
            </div>

            {/* Author Bio */}
            <div className="mt-16 p-8 bg-porcelain">
              <div className="flex items-start gap-6">
                <div className="w-20 h-20 bg-charcoal rounded-full flex items-center justify-center text-white font-bold text-2xl flex-shrink-0">
                  {column.author_name.charAt(0)}
                </div>
                <div>
                  <h3 className="font-display text-xl font-bold text-charcoal mb-2">
                    {column.author_name}
                  </h3>
                  <p className="text-sm text-stone leading-relaxed">
                    Colunista da Revista Enfoco. Especialista em cultura, sociedade e tendências contemporâneas.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </article>
  );
};

export default SingleColumn;
